import datetime


def get_date_time():
    current = datetime.datetime.now()
    time = current.strftime("%X")
    return time


def print_menu():
    print("\n\n\n\n")
    print("*" * 40)
    print(" Warehouse control system" + get_date_time())
    print("*" * 40)

    print("[1] Register new item")
    print("[2] List the items on the system")
    print("[3] Update quantity on stock for a selected item")
    print("[4] List item with stock (stock > 0)")
    print("[5] Remove item for the system")
    print("[6] Register an entry")
    print("[7] Output an item")
    print("[8] Print Log")
    print("[9] Inventory Log")

    print("x- exit the system")
