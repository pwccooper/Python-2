

"""
Program: Warehouse control system
Functionality:
  1  - register new items on the system
        *id (auto generate this)
        *title
        *type
        *price
        *stock

  2 - list the items on the system
  3 - update quantity on stock for a selected item
  4 - list item with stock (stock > 0)


"""
import sys
from menu import print_menu
from item import item

import datetime
import pickle

import os


def clear(): return os.system('cls')


items = []
event_log = []
id_count = 1
items_file = "items.data"
log_file = "log.data"


# def clear():
#   print("\033[H\033[J")


def save_items():
    try:
        writer = open(items_file, "wb")
        pickle.dump(items, writer)
        writer.close()
        print("Data saved!!")

    except:
        print(" **Error: Data not saved ")


def save_log():
    try:
        writer = open(log_file, "wb")
        pickle.dump(event_log, writer)
        writer.close()
        print("Log saved!!")

    except:
        print("Error: Sorry log couldn't be saved!")


def read_items():
    global id_count
    global items_file

    try:
        reader = open(items_file, "rb")
        temp_data = pickle.load(reader)

        for item in temp_data:
            items.append(item)

        last = items[-1]
        id_count = last.id + 1

        print("Data loaded: " + str(len(items)) + " items")

    except:
        print("*Error: Data not loaded")


def remove_item():
    item = select_item()
    if(item is not None):
        try:
            items.remove(item)
            print("Item Removed!")

        except:
            print("Error: Item wasn't removed!")
            print("**Error: ", sys.exc_info()[0])


def print_inventory_value():
    print("*" * 40)
    print(" Inventory Value")
    print("*" * 40)

    total = 0
    for item in items:
        val = item.price * item.stock
        total += val

    print(" Total value of the stock: " + str(total))
    print("\n")
    print("*" * 40)


def register_entry(action):
    item = select_item()
    how_many = int(input("How many items: "))
    if(item is not None):
        print("updating info")

        if(action == 1):
            item.stock += how_many
            event = str(item.id) + " " + str(how_many) + " input"
            event_log.append(event)
        elif(action == 2):
            item.stock += how_many
            event = str(item.id) + " " + str(how_many) + " output"
            event_log.append(event)

        save_log()


def read_events():
    global log_file

    try:
        reader = open(log_file, "rb")
        temp_data = pickle.load(reader)

        for event in temp_data:
            event_log.append(event)

        print("Events loaded ")

    except:
        print("**Error: Log Events could not be loaded! ")


def register_item():
    global id_count
    try:
        id = id_count
        title = input("Input title: ")
        cat = input("Input category:")
        price = float(input("Input price: "))
        stock = int(input("Input stock: "))

        new_item = item(id, title, cat, price, stock)

        items.append(new_item)
        print(new_item.price)

    except:
        print("** Error, check data and try again")


def print_log():
    print("*" * 40)
    print("Log of events")
    print("*" * 40)
    for event in event_log:
        print(event)


def list_all():
    print("*" * 100)
    print(" List of all items ")
    print("*" * 100)
    for item in items:

        print(str(item.id) + " - " + format_left(20, item.title) + " category: " +
              format_left(30, item.category) + " $" + str(item.price) + " # " + str(item.stock))

    print("*" * 100)
    if (len(items) < 1):
        print("- Empty Db, use opc 1 to create an item - ")
        print("*" * 100)


def update_stock():
    item = select_item()
    if(item is not None):
        try:
            new_stock = int(input("Please provide new Stock value: "))
            item.stock = new_stock
            print("Status: Stock value updated")

        except:
            print("Error: Stock should be a integer number, try again.")


def list_with_stock():
    print("*" * 100)
    print(" List of all items ")
    print("*" * 100)
    for item in items:
        if(item.stock > 0):
            print(str(item.id) + " - " + format_left(20, item.title) + " $" +
                  str(item.price) + "  " + str(item.stock))

    print("*" * 100)

    print("*" * 40)


def select_item():
    list_all()
    selection = int(input("id of item: "))

    for item in items:
        if(item.id == selection):
            return item

    print(" *Error: ID not found, check and try again")
    return None


def format_left(how_many, text):
    if(len(text) == how_many):
        return text

    if(len(text) > how_many):
        return text[0: how_many]

    while(len(text) < how_many):
        text = text + " "

    return text


read_items()
read_events()


opc = ''
while(opc != 'x'):
    print_menu()
    opc = input("Select an option: ")

    if(opc == "1"):
        register_item()
        save_items()
    elif(opc == "2"):
        list_all()
    elif(opc == "3"):
        update_stock()
        save_items()
    elif(opc == "4"):
        list_with_stock()
    elif(opc == "5"):
        remove_item()
        save_items()
    elif(opc == "6"):
        register_entry(1)
        save_items()
    elif(opc == "7"):
        register_entry(2)
        save_items()
    elif(opc == "8"):
        print_log()
    elif(opc == "9"):
        print_inventory_value()
    if(opc != 'x'):
        input("\n\n Press Enter to Continue ")

print("Thank you!!")
